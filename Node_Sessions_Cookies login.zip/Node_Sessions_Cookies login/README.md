# Authentication_Node_Sessions_Cookies
This is the refactored and cleaned code from the Understanding Auth in Node using Sessions and Cookies

In this project I tried to keep things simple and try to hammer in the concepts behind using Sessions
and Cookies for Authentication. I did refactor the code from the video to make it more readable for review.

To use this code do the following:
1. Clone this repo or download it.
2. Navigate into the location you downloaded folder in your cmd/bash/terminal
3. Run npm install to install all the depends in this projects (express, express-session, mongoose, ejs, bcryptjs, connect-mongodb-session)
4. Check inside of the config folder under the default.json for the mongodb URI and insert your own connection string 

Hope you found this helpfull and I will see you in the next one...!
